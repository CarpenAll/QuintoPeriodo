/* Introdução 
    console.log("Aula Teste");
    console.log(document.querySelector(".titulo-alunos"));
    let tituloAlunos = document.querySelector(".titulo-alunos");
    console.log('varTituloAlunos: ', tituloAlunos);
    tituloAlunos.textContent = "Unidep Teste IMC";
*/
/********************************************************************/

/* Atividade */
let paciente = document.querySelector("#primeiro-paciente");
let tdPeso = paciente.querySelector(".info-peso");

let nome = 15;
console.log(nome);
console.log(tdPeso);

/* Exemplo Java
String  nome = "";
double  valor = 1.20;
Integer codigo = 1;
char    sexo = 'F';

chave | valor
nome  | "Lucas"

 */