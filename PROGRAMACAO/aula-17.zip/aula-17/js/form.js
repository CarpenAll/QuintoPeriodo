var botaoAdicionar = document.querySelector("#adicionar-paciente");
botaoAdicionar.addEventListener("click", function (event) {
    event.preventDefault();

    var form = document.querySelector("#form-adiciona");

    var pacienteRetornado = obtemPacienteDoFormulario(form);

    var pacienteTr = montarTr(pacienteRetornado);

    /* 1° Exemplo - Validação com retorno booleano */
    // if (!validarPaciente(pacienteRetornado)) {
    //     console.log("Dados inválidos!");
    //     return;
    // }

    /* 2° Exemplo - Validação com retorno de uma String */
    var erro = validarPaciente(pacienteRetornado);
    if (erro != undefined) {
        var spanMensagemErro = document.querySelector("#mensagem-erro");
        spanMensagemErro.textContent = erro;
        return;
    }

    console.log("Continua a inserção da linha.");
    /* Pegar o elemento da tabela */
    var tabela = document.querySelector("#tabela-pacientes");

    /* Inserir a linha na tabela */
    tabela.appendChild(pacienteTr);
});

function obtemPacienteDoFormulario(form) {
    /* Valores informados no formulário. */
    let paciente = {
        nome: form.nome.value,
        peso: form.peso.value,
        altura: form.altura.value,
        gordura: form.gordura.value,
        imc: calculaImc(form.peso.value, form.altura.value)
    }
    return paciente;
}

function montarTr(pacienteRetornado) {
     /* Elemento de linha da tabela criada. */
     var pacienteTr = document.createElement("tr");
     pacienteTr.classList.add("paciente");

     pacienteTr.appendChild(montaTd(pacienteRetornado.nome, "info-nome"));
     pacienteTr.appendChild(montaTd(pacienteRetornado.peso, "info-peso"));
     pacienteTr.appendChild(montaTd(pacienteRetornado.altura, "info-altura"));
     pacienteTr.appendChild(montaTd(pacienteRetornado.gordura, "info-gordura"));
     pacienteTr.appendChild(montaTd(pacienteRetornado.imc, "info-imc"));

     return pacienteTr;
}

function montaTd(dado, classe) {
    var td = document.createElement("td");
    td.classList.add(classe);
    td.textContent = dado;
    return td;
}

function validarPaciente(paciente) {
    /* 1° Exemplo - Validação com retorno booleano */
    // if (validaPeso(paciente.peso) && validaAltura(paciente.altura)) {
    //     return true;
    // } else {
    //     return false;
    // }

    /* 2° Exemplo - Validação com retorno de uma String */
    if (!validaPeso(paciente.peso)) {
        return "O peso é inválido!";
    }

    if (!validaAltura(paciente.altura)) {
        return "A altura é inválida!"
    }

}